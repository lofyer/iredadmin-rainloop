<?php

namespace GuzzleHttp\Exception;

class AdapterException extends TransferException {}
