<?php

namespace RainLoop\Enumerations;

class Layout
{
	const NO_PREVIW = 0;
	const SIDE_PREVIEW = 1;
	const BOTTOM_PREVIEW = 2;
}
