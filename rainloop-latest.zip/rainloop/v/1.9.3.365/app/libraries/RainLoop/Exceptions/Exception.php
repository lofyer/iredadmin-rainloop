<?php

namespace RainLoop\Exceptions;

class Exception extends \Exception {}
